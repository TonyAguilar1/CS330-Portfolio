///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////
#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <GLFW/glfw3.h>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>

namespace {
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

SceneManager::SceneManager(ShaderManager* pShaderManager) {
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
	m_textureIDs.clear();
}

SceneManager::~SceneManager() {
	m_pShaderManager = nullptr;
	delete m_basicMeshes;
	DestroyGLTextures();
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0, height = 0, colorChannels = 0;
	GLuint textureID = 0;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image)
	{
		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else {
			stbi_image_free(image);
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		TEXTURE_INFO tex;
		tex.tag = tag;
		tex.ID = textureID;
		m_textureIDs.push_back(tex);
		++m_loadedTextures;
		return true;
	}

	return false;
}

void SceneManager::DestroyGLTextures()
{
	for (const auto& tex : m_textureIDs) {
		glDeleteTextures(1, &tex.ID);
	}
	m_textureIDs.clear();
	m_loadedTextures = 0;
}

int SceneManager::FindTextureID(std::string tag)
{
	for (const auto& tex : m_textureIDs) {
		if (tex.tag == tag)
			return tex.ID;
	}
	return -1;
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (!m_pShaderManager) return;
	int textureID = FindTextureID(textureTag);
	if (textureID == -1) return;

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, textureID);
	m_pShaderManager->setIntValue(g_UseTextureName, true);
	m_pShaderManager->setSampler2DValue(g_TextureValueName, 0);
}

void SceneManager::SetTransformations(glm::vec3 scale, float rotX, float rotY, float rotZ, glm::vec3 position)
{
	glm::mat4 model =
		glm::translate(position) *
		glm::rotate(glm::radians(rotZ), glm::vec3(0, 0, 1)) *
		glm::rotate(glm::radians(rotY), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::radians(rotX), glm::vec3(1, 0, 0)) *
		glm::scale(scale);

	if (m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, model);
	}
}

void SceneManager::SetShaderColor(float red, float green, float blue, float alpha)
{
	if (!m_pShaderManager) return;
	glm::vec4 color(red, green, blue, alpha);
	m_pShaderManager->setIntValue(g_UseTextureName, false);
	m_pShaderManager->setVec4Value(g_ColorValueName, color);
}



/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}



/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& materialOut)
{
	for (const auto& material : m_objectMaterials)
	{
		if (material.tag == tag)
		{
			materialOut = material;
			return true;
		}
	}
	return false;
}


void SceneManager::LoadSceneTextures()
{
	struct TextureEntry {
		const char* filePath;
		const char* objectName;
	};

	std::vector<TextureEntry> textures = {
		{ "../../Projects/7-1_FinalProjectMilestones/textures/drywall.jpg",    "floor" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/purple.jpg",    "big box" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/purple.jpg",    "left box" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/purple.jpg",    "right box" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/stainless.jpg", "left joystick" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/stainless.jpg", "left joystick pad" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/stainless.jpg", "right joystick" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/stainless.jpg", "right joystick pad" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/rusticwood.jpg","button 1" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/rusticwood.jpg","button 2" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/rusticwood.jpg","button 3" },
		{ "../../Projects/7-1_FinalProjectMilestones/textures/rusticwood.jpg","button 4" },
		
	
	};

	for (const auto& tex : textures)
	{
		CreateGLTexture(tex.filePath, tex.objectName);
	}

	
}


void SceneManager::SetShaderMaterial(std::string tag)
{
	if (!m_pShaderManager)
		return;

	OBJECT_MATERIAL material;
	if (!FindMaterial(tag, material)) {
		// If material not found, optionally set default values
		std::cerr << "Material not found: " << tag << std::endl;
		return;
	}

	// Send material values to the shader
	m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
	m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
	m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
	m_pShaderManager->setFloatValue("material.shininess", material.shininess);
	m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()


{
	// load the textures for the 3D scene
	LoadSceneTextures();
	DefineObjectMaterials();
	SetUpSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
}

void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL goldMaterial;
	goldMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	goldMaterial.ambientStrength = 0.4f;
	goldMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	goldMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	goldMaterial.shininess = 22.0;
	goldMaterial.tag = "gold";

	m_objectMaterials.push_back(goldMaterial);

	OBJECT_MATERIAL cementMaterial;
	cementMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	cementMaterial.ambientStrength = 0.4f;
	cementMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	cementMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	cementMaterial.shininess = 22.0;
	cementMaterial.tag = "cement";

	m_objectMaterials.push_back(cementMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	woodMaterial.ambientStrength = 0.4f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	woodMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	woodMaterial.shininess = 22.0;
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL tileMaterial;
	tileMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	tileMaterial.ambientStrength = 0.4f;
	tileMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	tileMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	tileMaterial.shininess = 22.0;
	tileMaterial.tag = "tile";

	m_objectMaterials.push_back(tileMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	glassMaterial.ambientStrength = 0.4f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	glassMaterial.shininess = 22.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL clayMaterial;
	clayMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
	clayMaterial.ambientStrength = 0.4f;
	clayMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	clayMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
	clayMaterial.shininess = 22.0;
	clayMaterial.tag = "clay";

	m_objectMaterials.push_back(clayMaterial);
}
void SceneManager::SetUpSceneLights()
{

	glm::vec3 viewPos(0.0f, 0.0f, 3.0f);

	m_pShaderManager->setVec3Value("viewPosition", viewPos.x, viewPos.y, viewPos.z);
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// Directional Light
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.2f, -1.0f, -0.3f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// Point Light 0
	m_pShaderManager->setVec3Value("pointLights[0].position", 3.0f, 14.0f, 0.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.8f, 0.8f, 0.8f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Disable other point lights (1�4)
	for (int i = 1; i < 5; ++i)
	{
		std::string base = "pointLights[" + std::to_string(i) + "]";
		m_pShaderManager->setBoolValue(base + ".bActive", false);
	}


	m_pShaderManager->setBoolValue("spotLight.bActive", false);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 40.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 1, 1, 1);
	// Bind the texture named "floor" to be used by the shader in rendering
	SetShaderTexture("floor");
	SetShaderMaterial("cement");
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/


	////Big Box
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 1.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 1.5f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(.29, 0, .51, 1);
	SetShaderMaterial("cement");
	// Bind the texture named "big box" to be used by the shader in rendering
	SetShaderTexture("big box");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	//SetShaderColor(0, 0, 0, 1);
	//m_basicMeshes->DrawBoxMeshLines();
	/****************************************************************/

		////left Box
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 3.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = -10.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 1.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(.29, 0, .51, 1);
	SetShaderMaterial("wood");
	// Bind the texture named "left box" to be used by the shader in rendering
	SetShaderTexture("left box");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/

		////Right Box
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 3.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 10.0f;
	ZrotationDegrees = 00.00f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.75f, 1.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(.29, 0, .51, 1);
	// Bind the texture named "rectangle" to be used by the shader in rendering
	SetShaderTexture("right box");
	SetShaderMaterial("glass");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/

		////Left joystick
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, .20f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.25f, 2.0f, 1.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "sphere" to be used by the shader in rendering
	SetShaderTexture("left joystick");
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/

	////left joystick pad
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.35f, .05f, 0.35f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.25f, 2.25f, 1.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("left joystick pad");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();



	/****************************************************************/

			////right joystick
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(.15f, .20f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.5f, 2.0f, 1.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("right joystick");
	SetShaderMaterial("tile");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();




	/****************************************************************/

		////right joystick pad
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.35f, .05f, 0.35f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.5f, 2.25f, 1.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("right joystick pad");
	SetShaderMaterial("clay");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();




	/****************************************************************/


			////button 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.12f, .05f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.75f, 2.0f, .65f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("button 1");
	SetShaderMaterial("clay");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();




	/****************************************************************/

			////button 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.12f, .05f, .10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.75f, 2.0f, 0.15f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("button 2");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();




	/****************************************************************/

			////button 3
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.12f, .05f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.45f, 2.0f, .35f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("button 3");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();




	/****************************************************************/

			////button 4
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.12f, .05f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.0f, 2.0f, .35f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("button 4");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();




	/****************************************************************/

		////directional 1
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.20f, .10f, 0.16f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.25f, 2.0f, .35f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("directional 1");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();




	/****************************************************************/


			////directional 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.20f, .10f, 0.16f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-.75f, 2.0f, .35f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("directional 2");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();




	/****************************************************************/

			////directional 3
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.20f, .10f, 0.16f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 2.0f, .55f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("directional 3");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();




	/****************************************************************/

			////directional 4
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.20f, .10f, 0.16f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.0f, 2.0f, .15f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("directional 4");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();




	/****************************************************************/

	////pause button
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(.30f, 0.05f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	//SetShaderColor(0, 0, 0, 1);
	// Bind the texture named "cone" to be used by the shader in rendering
	SetShaderTexture("pause");
	SetShaderMaterial("tile");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// Sphere Light
	scaleXYZ = glm::vec3(0.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 5.0f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 0.2f, 0.8f, 1.0f);  // Purple glow
	SetShaderMaterial("glass");
	m_basicMeshes->DrawSphereMesh();

	// Pyramid Totem Base
	scaleXYZ = glm::vec3(1.0f, 0.2f, 1.0f);
	positionXYZ = glm::vec3(4.0f, 0.1f, -2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("button 4");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Pyramid Totem Top
	scaleXYZ = glm::vec3(0.8f, 0.6f, 0.8f);
	positionXYZ = glm::vec3(4.0f, 0.6f, -2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("button 4");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawPyramid4Mesh();

	// Torus Decoration
	scaleXYZ = glm::vec3(0.5f);
	positionXYZ = glm::vec3(-2.0f, 0.1f, 2.0f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("right joystick");
	SetShaderMaterial("tile");
	m_basicMeshes->DrawTorusMesh();
	
}

